﻿using System.ComponentModel.DataAnnotations;

namespace ConverterMetricImperialDemo.Common.Models
{
    public class ConvertRequest
    {
        /// <summary>
        /// Amount to convert.
        /// </summary>
        [Required]
        public double AmountToConvert { get; set; }
        /// <summary>
        /// The direction in which to convert (Imperial to Metric / Metric to Imperial).
        /// </summary>
        [Required]
        public ConversionDirection ConversionDirection { get; set; }
        /// <summary>
        /// The type of conversion (Length / Temperature / Mass).
        /// </summary>
        [Required]
        public ConversionType ConversionType { get; set; }
    }
}
