﻿namespace ConverterMetricImperialDemo.Common
{
    public enum ConversionDirection
    {
        MetricToImperial,
        ImperialToMetric
    }
}
