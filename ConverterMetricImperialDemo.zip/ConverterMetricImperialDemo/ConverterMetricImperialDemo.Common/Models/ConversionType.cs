using System;

namespace ConverterMetricImperialDemo.Common
{
    public enum ConversionType
    {
        Temperature,
        Length,
        Mass
    }
}
