﻿using ConverterMetricImperialDemo.Service;
using ConverterMetricImperialDemo.Service.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace ConverterMetricImperialDemo.Api.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddServices(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IConvertService, ConvertService>();
            return serviceCollection;
        }
    }
}
