﻿using ConverterMetricImperialDemo.Common;
using ConverterMetricImperialDemo.Data;
using ConverterMetricImperialDemo.Service.Interfaces;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System;
using System.Data;

namespace ConverterMetricImperialDemo.Service
{
    /// <summary>
    /// Class <c>ConvertService</c> To make conversion.
    /// </summary>
    public class ConvertService : IConvertService
    {
        private readonly ConversionDbContext _context;

        public ConvertService(ConversionDbContext context)
        {
            _context = context;
        }

        /// <inheritdoc/>
        public async Task<double> ConvertAsync(double amountToConvert, ConversionDirection conversionDirection, ConversionType conversionType)
        {
            var conversionRate = await _context.ConversionRates.SingleOrDefaultAsync(conversionRate => conversionRate.Type == (int)conversionType && conversionRate.Direction == (int)conversionDirection);
            if (conversionRate == null)
            {
                throw new ArgumentException("Conversion rate can not be found");
            }

            var expression = conversionRate.Formula.Replace("{value}", amountToConvert.ToString());

            var dt = new DataTable();
            var computeResult = dt.Compute(expression, string.Empty);
            if (!double.TryParse(computeResult?.ToString(), out double convertedAmount))
            {
                throw new Exception("Invalid expression");
            }

            return Math.Round(convertedAmount,3);
        }
    }
}
