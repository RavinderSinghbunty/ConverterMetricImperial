﻿using ConverterMetricImperialDemo.Common;
using System.Threading.Tasks;

namespace ConverterMetricImperialDemo.Service.Interfaces
{
    public interface IConvertService
    {
        /// <summary>
        /// Converts a unit between Metric and Imperial.
        /// </summary>
        /// <param name="amountToConvert">amountToConvert double value</param>
        /// <param name="conversionDirection">conversionDirection Enum Value</param>
        /// <param name="conversionType">conversionType Enum Value </param>
        /// <returns></returns>
        public Task<double> ConvertAsync(double amountToConvert, ConversionDirection conversionDirection, ConversionType conversionType);
    }
}
